"""
Created on Thu Feb 13 19:18:26 2020
@author: Can KIZILKALE
"""

#Approximate Error Correction for phylogenetic tree matrices.
#Can Kizilkale

import os
import time
import copy
import numpy as np
import pandas as pd
import networkx as nx
from datetime import datetime
import argparse
from argparse import ArgumentParser
import itertools
#import multiprocessing as mp

def compareAD(M1,M2): #M1 is the ground truth
    error_pairs=[]
    n_adpairs=0
    for i in range(M1.shape[1]):
#        print(i)
        for j in range(i,M1.shape[1]):
            cap1=M1[:,i]*M1[:,j]
            cap2=M2[:,i]*M2[:,j]
            if (np.sum(cap1)>0 and np.sum(M1[:,i]) != np.sum(M1[:,j])):
                n_adpairs=n_adpairs+1
                if (np.sum(cap2)==0):
                    error_pairs.append([i,j])
                else:
                    if (np.sum(M1[:,j])>np.sum(M1[:,i]) and np.sum(M2[:,j])<=np.sum(M2[:,i])):
                        error_pairs.append([i,j])
                    else:
                        if (np.sum(M1[:,i])>np.sum(M1[:,j]) and np.sum(M2[:,i])<=np.sum(M2[:,j])):
                            error_pairs.append([i,j])
                        #print(i,j,sum(M1[:,i]),sum(M1[:,j]),sum(M2[:,i]),sum(M2[:,j]))
    print('Number of AD pairs = ',n_adpairs,"errors : ",len(error_pairs), "AD score = ", 1 - len(error_pairs)/n_adpairs)
    return (1 - len(error_pairs)/n_adpairs)                

def compareDF(M_orj,M_rec):
    error_pairs=[]
    d_pairs=0
    for i in range(M_orj.shape[1]):
        for j in range(i,M_orj.shape[1]):
            cap1=M_orj[:,i]*M_orj[:,j]
            cap2=M_rec[:,i]*M_rec[:,j]
            if np.sum(cap1)==0:
                d_pairs=d_pairs + 1
                if np.sum(cap2)>0:
                    error_pairs.append([i,j])
    print("Number of Diff pairs = ",d_pairs, "errors :",len(error_pairs), "score :", 1-len(error_pairs)/d_pairs)
    return (1-len(error_pairs)/d_pairs)
            
def ReadFasis(filename): # reads a matrix from file and returns it in BOOL type
    df = pd.read_csv(filename, sep='\t', index_col=0)
    M=df.values
    return M        


#-------------------For Huntress---------------------------------------------

files=os.listdir()
n_cpu=8
for f in files:
    Scorelog=open("No_NA_fp03_ratio_10_AD_DF.scores", "a+")
    inputfile=f
    outputfile=inputfile
    groundfile=inputfile + ".before_FP_FN_NA"
    if f.endswith(".SC") and f.startswith("simNo") and os.path.exists(groundfile):
        Pfn=float(inputfile.split("fn_")[1].split("-")[0])
        Pfp=0.03
        reconstructedfile=inputfile+".CFMatrix"
        #mycommand="python huntress.py "+ inputfile + " " + outputfile + " " + "--nofcpus " + str(n_cpu)  +" --fp_coeff "+str(Pfp) +" --fn_coeff "+str(Pfn) + " --fn_fpratio " + str(10)# used default values
        mycommand="python huntress.py "+ inputfile + " " + outputfile + " --fn_fpratio " + str(2)+" --nofcpus " + str(n_cpu)# used default values              
        #+ " --fp_coeff " + str(0.00001) + " --fn_fpratio " + str(25)+ " --fn_fpratio " + str(25)
        t_start=time.time()
        #Reconstruct(args.inputfile,args.outputfile,Algchoice="FPNA",n_proc=mp.cpu_count(),fnfp=51,post_fn=fn_conorm,post_fp=fp_conorm)
        os.system(mycommand)
        t_end=time.time()
        M_g=ReadFasis(groundfile)
        if os.path.exists(reconstructedfile):
            M_r=ReadFasis(reconstructedfile)
            print(inputfile, " \ ",compareAD(M_g,M_r), " \ ", compareDF(M_g,M_r)," \ ", "Elapsed time: " , t_end-t_start," \ ", "n of cpus: ", n_cpu, file=Scorelog )
            #print(inputfile, " \ ",compareAD(M_g,M_r), " \ ", compareDF(M_g,M_r), "Completed !...")
        else:
            print(inputfile, " Reconstruction NOT found ! ", file=Scorelog )
            
        #----------------Clean up--------------
        files=os.listdir()
        for f_delete in files:
            if "TEMP" in f_delete:
                os.remove(f_delete)
        #---------------------------------------
        
    Scorelog.close()


#------------------------------------------------------------------------------------